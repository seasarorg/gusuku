DELETE FROM PROJECT_GROUPBASE
WHERE PROJECTID = /*projectGroupbase.projectid*/ AND GROUPBASEID = /*projectGroupbase.groupbaseid*/
