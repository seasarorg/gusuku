package tool;

import org.seasar.framework.container.factory.SingletonS2ContainerFactory;
import org.seasar.gusuku.dao.ReportDao;
import org.seasar.gusuku.entity.Report;
import org.seasar.gusuku.interceptor.NonAuthenticateAware;
import org.seasar.gusuku.web.GusukuAction;
import org.seasar.xwork.annotation.Param;
import org.seasar.xwork.annotation.Result;
import org.seasar.xwork.annotation.XWorkAction;


public class InsertAction extends GusukuAction implements NonAuthenticateAware {
	
	private ReportDao reportDao;
	@XWorkAction(name = "insert", result = @Result(type = "mayaa", param = @Param(name = "location", value = "/index.html")))
	public String execute(){
		reportDao = (ReportDao)SingletonS2ContainerFactory.getContainer().getComponent(ReportDao.class);
		for(int i=1;i<=100000;i++){
			Report report = new Report();
			report.setTitle("レコード件数テスト["+i+"]");
			report.setReporterid((long)(i%2+1));
			report.setProjectid(1l);
			report.setTypeid((long)(i%2+1));
			report.setResolutionid((long)(i%6+1));
			report.setStatusid((long)(i%5+1));
			report.setPriorityid((long)(i%4+1));
			report.setEnvironment("環境"+i);
			report.setDetail("レコード件数テスト"+i);
			report.setKey("DUMMY-"+ i);
			report.setMessageid("");
			if(i <= 100){
				report.setAssigneeid(1l);
			}
			reportDao.insert(report);
		}
		
		return SUCCESS;
	}

	
	public ReportDao getReportDao() {
		return reportDao;
	}

	
	public void setReportDao(ReportDao reportDao) {
		this.reportDao = reportDao;
	}
	
	

}
