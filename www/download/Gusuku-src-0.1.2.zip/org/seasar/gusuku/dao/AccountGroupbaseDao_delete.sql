DELETE FROM ACCOUNT_GROUPBASE
WHERE ACCOUNTID = /*accountGroupbase.accountid*/ AND GROUPBASEID = /*accountGroupbase.groupbaseid*/
